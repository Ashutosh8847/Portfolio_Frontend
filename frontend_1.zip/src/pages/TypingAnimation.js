import React from 'react';
import useTypingEffect from './useTypingEffect';

const TypingAnimation = () => {
  const phrases = [
    'Software Developer.',
    'Data Analyst.',
    'Full Stack Software Developer.',
    'Backend Developer.',
    'Frontend Developer.'
  ];
  const displayedText = useTypingEffect(phrases, 150);

  return (
    <div>
      <h3>
      I am a :<b>{displayedText}</b> 
        <span className="cursor"></span>
      </h3>
    </div>
  );
};

export default TypingAnimation;
