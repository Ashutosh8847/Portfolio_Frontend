import React from 'react'
import './Experience.css'
import { MdWork } from "react-icons/md";

const Experience = () => {
    return (
        <div className='experienceConatiner' style={{ marginTop: "30px" }}>
            <h2 style={{ textAlign: "center" }}><span style={{ marginRight: "10px", fontSize: "32px" }}><MdWork /></span><b>Work Experience:<hr/></b></h2>
            <ul>
                <li>
                    <b>Position:</b> Associate Software Engineer , Conversational AI Chatbot Developer.<br />
                    <b>Organization:</b>smartbots.ai, a subsidiary of Palni India Pvt Ltd<br />
                    <b>Location:</b>Hyderabad, Telangana<br />
                    <b>Duration:</b>November 2022 – Present<br />
                    <b>Responsibilities:</b>
                    <ul>
                        <li>
                            Developed and integrated sophisticated chat and voice bots using advanced AI solutions and AWS tools such as Lex, Lambda, Connect, DynamoDB, and S3 etc...
                        </li>
                        <li>
                            Created WhatsApp bots for diverse industries including Travel & Hospitality, Insurance, and Telecom, enhancing customer support and operational efficiency.
                        </li>
                        <li>
                        Completed notable projects for telecom companies, utilizing cutting-edge technologies to develop functional and effective chatbots.</li>
                        <li>
                        Currently involved in a project for a pharmaceutical company, focusing on streamlining sales operations and enhancing customer engagement through AI-driven solutions integrated with Salesforce.                        </li>

                    </ul>


                </li>
            </ul>
        </div>
    )
}

export default Experience
